# ===============================================================
# BEER QUALITY - SOLUTION ULTIME AVEC ANALYSE COMPLETE
# ===============================================================
# Objectif: Maximiser le score Kaggle avec analyse exploratoire complète
# Temps d'exécution: < 20 minutes
# Sorties:
#   - submission.csv (fichier de soumission Kaggle)
#   - Analyses statistiques et visualisations
# ===============================================================

import os
import sys
import subprocess
import warnings
import time
warnings.filterwarnings("ignore")

# ============================
# INSTALLATION DES DÉPENDANCES
# ============================
def ensure_package(pkg, pip_name=None):
    """
    Installe automatiquement un package Python s'il n'est pas disponible.

    Args:
        pkg: Nom du module à importer
        pip_name: Nom du package pip (si différent du nom du module)

    Returns:
        True si le package est disponible
    """
    pip_name = pip_name or pkg
    try:
        __import__(pkg)
        return True
    except ImportError:
        print(f"Installation de {pip_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", pip_name])
        __import__(pkg)
        return True

# Installation des packages nécessaires
have_xgb = ensure_package("xgboost")
have_lgb = ensure_package("lightgbm")
ensure_package("imblearn", "imbalanced-learn")
ensure_package("seaborn")
ensure_package("matplotlib")

# ============================
# IMPORTS
# ============================
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Mode non-interactif pour générer les graphiques
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from scipy import stats
from scipy.stats import mode

# Scikit-learn
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression

# Modèles avancés
if have_xgb:
    from xgboost import XGBClassifier
if have_lgb:
    from lightgbm import LGBMClassifier

# SMOTE pour équilibrage
from imblearn.over_sampling import SMOTE

print("="*70)
print("BEER QUALITY PREDICTION - ANALYSE COMPLETE ET MODELISATION")
print("="*70)

start_time = time.time()

# ============================
# CHARGEMENT DES DONNÉES
# ============================
print("\n[1/8] Chargement des données...")

SCRIPT_DIR = Path(__file__).parent
BASE = SCRIPT_DIR / "data"

train = pd.read_csv(BASE / "train.csv", sep=";")
test = pd.read_csv(BASE / "test.csv", sep=";")
sample_submission = pd.read_csv(BASE / "sample_submission.csv")

target = "quality"
id_col = "id"
features = [c for c in train.columns if c not in (target, id_col)]

print(f"  -> Train: {train.shape[0]} lignes, {train.shape[1]} colonnes")
print(f"  -> Test: {test.shape[0]} lignes, {test.shape[1]} colonnes")
print(f"  -> Features: {len(features)}")
print(f"  -> Classes cible: {sorted(train[target].unique())}")

# ============================
# ANALYSE EXPLORATOIRE (EDA)
# ============================
print("\n[2/8] Analyse exploratoire des données (EDA)...")

# Créer un dossier pour les visualisations
viz_dir = SCRIPT_DIR / "visualizations"
viz_dir.mkdir(exist_ok=True)

# ---- Analyse univariée ----
print("  -> Analyse univariée...")

# Distribution de la variable cible
plt.figure(figsize=(10, 6))
train[target].value_counts().sort_index().plot(kind='bar', color='steelblue', edgecolor='black')
plt.title('Distribution de la Qualité de la Bière (Variable Cible)', fontsize=14, fontweight='bold')
plt.xlabel('Qualité', fontsize=12)
plt.ylabel('Nombre d\'échantillons', fontsize=12)
plt.xticks(rotation=0)
plt.grid(axis='y', alpha=0.3)
plt.tight_layout()
plt.savefig(viz_dir / "01_distribution_cible.png", dpi=100)
plt.close()

# Statistiques descriptives des variables numériques
numeric_features = train[features].select_dtypes(include=[np.number]).columns.tolist()
desc_stats = train[numeric_features].describe()
desc_stats.to_csv(viz_dir / "stats_descriptives.csv")

print(f"    OK Variables numériques: {len(numeric_features)}")
print(f"    OK Distribution cible sauvegardée")

# ---- Analyse bivariée ----
print("  -> Analyse bivariée...")

# Boxplots des features importantes vs qualité
important_features = ['alcohol_ABV', 'bitterness_IBU', 'original_gravity', 'final_gravity', 'pH']
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for i, feat in enumerate(important_features):
    if feat in train.columns:
        train.boxplot(column=feat, by=target, ax=axes[i])
        axes[i].set_title(f'{feat} vs Qualité')
        axes[i].set_xlabel('Qualité')
        axes[i].set_ylabel(feat)

plt.suptitle('Analyse Bivariée: Features Clés vs Qualité', fontsize=14, fontweight='bold', y=1.00)
plt.tight_layout()
plt.savefig(viz_dir / "02_analyse_bivariee.png", dpi=100)
plt.close()

print(f"    OK Boxplots bivariés sauvegardés")

# ---- Analyse multivariée ----
print("  -> Analyse multivariée...")

# Matrice de corrélation
correlation_matrix = train[numeric_features].corr()

plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=False, cmap='coolwarm', center=0,
            square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
plt.title('Matrice de Corrélation des Variables Numériques', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig(viz_dir / "03_matrice_correlation.png", dpi=100)
plt.close()

# Sauvegarder la matrice de corrélation
correlation_matrix.to_csv(viz_dir / "matrice_correlation.csv")

print(f"    OK Matrice de corrélation sauvegardée")

# Corrélations avec la cible
target_encoded = LabelEncoder().fit_transform(train[target])
correlations_with_target = pd.DataFrame({
    'Feature': numeric_features,
    'Correlation': [train[feat].corr(pd.Series(target_encoded)) for feat in numeric_features]
}).sort_values('Correlation', key=abs, ascending=False)

correlations_with_target.to_csv(viz_dir / "correlations_avec_cible.csv", index=False)

print(f"    OK Top 5 corrélations avec la cible:")
for _, row in correlations_with_target.head(5).iterrows():
    print(f"      - {row['Feature']}: {row['Correlation']:.4f}")

# ---- Analyse Quantitative vs Qualitative ----
print("  -> Analyse variables qualitatives vs quantitatives...")

categorical_features = train[features].select_dtypes(include=['object']).columns.tolist()
print(f"    OK Variables catégorielles: {len(categorical_features)}")

if 'beer_style' in categorical_features:
    # Distribution de beer_style
    plt.figure(figsize=(12, 6))
    train['beer_style'].value_counts().head(15).plot(kind='barh', color='coral', edgecolor='black')
    plt.title('Top 15 Styles de Bière (Variable Catégorielle)', fontsize=14, fontweight='bold')
    plt.xlabel('Nombre d\'échantillons')
    plt.ylabel('Style de Bière')
    plt.tight_layout()
    plt.savefig(viz_dir / "04_styles_biere.png", dpi=100)
    plt.close()

    # Qualité moyenne par style
    quality_by_style = train.groupby('beer_style')[target].mean().sort_values(ascending=False).head(15)
    plt.figure(figsize=(12, 6))
    quality_by_style.plot(kind='barh', color='lightgreen', edgecolor='black')
    plt.title('Qualité Moyenne par Style de Bière (Top 15)', fontsize=14, fontweight='bold')
    plt.xlabel('Qualité Moyenne')
    plt.ylabel('Style de Bière')
    plt.tight_layout()
    plt.savefig(viz_dir / "05_qualite_par_style.png", dpi=100)
    plt.close()

print(f"\n  OK Toutes les analyses EDA sauvegardées dans: {viz_dir}")

# ============================
# FEATURE ENGINEERING
# ============================
print("\n[3/8] Feature Engineering...")

def create_advanced_features(df):
    """
    Crée des features avancées basées sur la chimie de la bière.

    Args:
        df: DataFrame avec les features originales

    Returns:
        DataFrame avec features enrichies
    """
    df = df.copy()

    # === Ratios et interactions ===
    if {'bitterness_IBU', 'alcohol_ABV'} <= set(df.columns):
        # Éviter division par zéro
        abv_safe = df['alcohol_ABV'].replace(0, 1e-6)

        # Ratio amertume/alcool (indicateur de style)
        df['IBU_per_ABV'] = df['bitterness_IBU'] / abv_safe

        # Produit amertume × alcool (intensité globale)
        df['IBU_x_ABV'] = df['bitterness_IBU'] * df['alcohol_ABV']

        # Log de l'amertume (réduire le skewness)
        df['log_IBU'] = np.log1p(df['bitterness_IBU'])
        df['log_ABV'] = np.log1p(df['alcohol_ABV'])

    if {'final_gravity', 'original_gravity'} <= set(df.columns):
        # Atténuation (fermentation complète)
        df['attenuation'] = df['original_gravity'] - df['final_gravity']

        # Ratio de gravité (indicateur de fermentation)
        og_safe = df['original_gravity'].replace(0, 1e-6)
        df['gravity_ratio'] = df['final_gravity'] / og_safe

        # Degré de fermentation
        df['fermentation_degree'] = (df['attenuation'] / og_safe) * 100

    if {'pH', 'alcohol_ABV'} <= set(df.columns):
        # Interaction pH × alcool
        df['pH_ABV'] = df['pH'] * df['alcohol_ABV']

    if {'color_SRM', 'bitterness_IBU'} <= set(df.columns):
        # Ratio couleur/amertume (style indicator)
        ibu_safe = df['bitterness_IBU'].replace(0, 1) + 1
        df['SRM_IBU_ratio'] = df['color_SRM'] / ibu_safe

    # Remplir les valeurs manquantes avec 0
    df = df.fillna(0)

    return df

# Appliquer le feature engineering
X_train = create_advanced_features(train[features].copy())
X_test = create_advanced_features(test[features].copy())

print(f"  -> Features originales: {len(features)}")
print(f"  -> Features après engineering: {X_train.shape[1]}")
print(f"  -> Nouvelles features créées: {X_train.shape[1] - len(features)}")

# ============================
# ENCODAGE DES VARIABLES
# ============================
print("\n[4/8] Encodage des variables...")

# Encoder les variables catégorielles
categorical_cols = X_train.select_dtypes(include=['object']).columns.tolist()
label_encoders = {}

for col in categorical_cols:
    # Combiner train et test pour avoir toutes les catégories
    all_values = pd.concat([X_train[col], X_test[col]], axis=0).astype(str)

    le = LabelEncoder()
    le.fit(all_values)

    X_train[col] = le.transform(X_train[col].astype(str))
    X_test[col] = le.transform(X_test[col].astype(str))

    label_encoders[col] = le

print(f"  -> Variables catégorielles encodées: {len(categorical_cols)}")

# Convertir en float32 pour optimisation mémoire
X_train = X_train.astype(np.float32)
X_test = X_test.astype(np.float32)

# Encoder la cible
le_target = LabelEncoder()
y_train = le_target.fit_transform(train[target])
n_classes = len(le_target.classes_)

print(f"  -> Nombre de classes: {n_classes}")
print(f"  -> Classes: {le_target.classes_}")

# ============================
# CONFIGURATION DES MODÈLES
# ============================
print("\n[5/8] Configuration des modèles (optimisé pour <20min)...")

N_SPLITS = 5
SEED = 42
skf = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=SEED)

def make_random_forest():
    """Random Forest avec hyperparamètres optimisés."""
    return RandomForestClassifier(
        n_estimators=500,              # Réduit pour vitesse
        max_depth=None,
        max_features='sqrt',           # Plus rapide que 0.8
        min_samples_split=2,
        min_samples_leaf=1,
        class_weight='balanced_subsample',
        n_jobs=-1,
        random_state=SEED
    )

def make_extra_trees():
    """Extra Trees avec hyperparamètres optimisés."""
    return ExtraTreesClassifier(
        n_estimators=600,              # Réduit pour vitesse
        max_depth=None,
        max_features='sqrt',
        min_samples_split=2,
        min_samples_leaf=1,
        n_jobs=-1,
        random_state=SEED
    )

def make_xgboost():
    """XGBoost avec hyperparamètres optimisés."""
    return XGBClassifier(
        objective='multi:softprob',
        num_class=n_classes,
        n_estimators=1500,             # Réduit pour vitesse
        learning_rate=0.05,            # Augmenté pour convergence plus rapide
        max_depth=8,                   # Réduit pour vitesse
        min_child_weight=2,
        subsample=0.90,
        colsample_bytree=0.85,
        reg_lambda=1.0,
        reg_alpha=0.1,
        tree_method='hist',            # Plus rapide
        eval_metric='mlogloss',
        n_jobs=-1,
        random_state=SEED
    )

def make_lightgbm():
    """LightGBM avec hyperparamètres optimisés."""
    return LGBMClassifier(
        objective='multiclass',
        num_class=n_classes,
        n_estimators=1500,             # Réduit pour vitesse
        learning_rate=0.05,
        num_leaves=256,                # Réduit pour vitesse
        max_depth=-1,
        min_child_samples=15,
        subsample=0.90,
        colsample_bytree=0.85,
        reg_lambda=0.5,
        reg_alpha=0.1,
        max_bin=255,
        n_jobs=-1,
        random_state=SEED,
        verbose=-1
    )

# Créer le dictionnaire de modèles
models = {
    'RF': make_random_forest(),
    'ET': make_extra_trees(),
    'XGB': make_xgboost() if have_xgb else None,
    'LGB': make_lightgbm() if have_lgb else None
}
models = {k: v for k, v in models.items() if v is not None}

print(f"  -> Modèles configurés: {list(models.keys())}")

# ============================
# ENTRAÎNEMENT DES MODÈLES
# ============================
print("\n[6/8] Entraînement des modèles avec validation croisée...")

# Stockage des prédictions OOF (Out-Of-Fold) et test
oof_predictions = {name: np.zeros((len(X_train), n_classes), dtype=np.float32)
                   for name in models}
test_predictions = {name: np.zeros((len(X_test), n_classes), dtype=np.float32)
                    for name in models}
model_scores = {}
all_fold_predictions = {name: [] for name in models}  # Pour matrice de confusion

for name, model in models.items():
    print(f"\n  -> Entraînement: {name}")
    fold_accuracies = []

    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train), 1):
        # Séparation train/validation
        X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
        y_tr, y_val = y_train[train_idx], y_train[val_idx]

        # SMOTE pour équilibrage (sur training fold uniquement)
        min_samples = min(np.bincount(y_tr))
        k_neighbors = min(3, max(1, min_samples - 1))

        try:
            smote = SMOTE(random_state=SEED + fold_idx, k_neighbors=k_neighbors)
            X_tr_balanced, y_tr_balanced = smote.fit_resample(X_tr, y_tr)
        except:
            X_tr_balanced, y_tr_balanced = X_tr, y_tr

        # Entraînement
        if name in ('XGB', 'LGB'):
            try:
                model.fit(
                    X_tr_balanced, y_tr_balanced,
                    eval_set=[(X_val, y_val)],
                    early_stopping_rounds=50,  # Réduit pour vitesse
                    verbose=False
                )
            except:
                model.fit(X_tr_balanced, y_tr_balanced)
        else:
            model.fit(X_tr_balanced, y_tr_balanced)

        # Prédictions OOF
        oof_pred = model.predict_proba(X_val).astype(np.float32)
        oof_predictions[name][val_idx] = oof_pred

        # Sauvegarder pour matrice de confusion
        all_fold_predictions[name].extend(oof_pred.argmax(1))

        # Score du fold
        fold_acc = accuracy_score(y_val, oof_pred.argmax(1))
        fold_accuracies.append(fold_acc)

        # Prédictions test (moyenne des folds)
        test_predictions[name] += model.predict_proba(X_test).astype(np.float32) / N_SPLITS

        print(f"    Fold {fold_idx}: Accuracy = {fold_acc:.5f}")

    # Score moyen OOF
    model_scores[name] = np.mean(fold_accuracies)
    print(f"    -> Score OOF moyen: {model_scores[name]:.5f}")

# ============================
# MATRICE DE CONFUSION
# ============================
print("\n  -> Génération des matrices de confusion...")

fig, axes = plt.subplots(2, 2, figsize=(15, 12))
axes = axes.flatten()

for idx, (name, oof_pred) in enumerate(oof_predictions.items()):
    if idx < 4:
        y_pred = oof_pred.argmax(1)
        cm = confusion_matrix(y_train, y_pred)

        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[idx],
                    xticklabels=le_target.classes_,
                    yticklabels=le_target.classes_)
        axes[idx].set_title(f'Matrice de Confusion - {name}\nAccuracy: {model_scores[name]:.4f}',
                           fontsize=12, fontweight='bold')
        axes[idx].set_xlabel('Prédiction')
        axes[idx].set_ylabel('Vraie Valeur')

plt.tight_layout()
plt.savefig(viz_dir / "06_matrices_confusion.png", dpi=100)
plt.close()

print(f"    OK Matrices de confusion sauvegardées")

# ============================
# ENSEMBLE ET META-MODÈLE
# ============================
print("\n[7/8] Création de l'ensemble et du méta-modèle...")

# Power blending (pondération selon performance^P)
P_POWER = 10.0
model_names = list(model_scores.keys())
accuracies = np.array([model_scores[name] for name in model_names])
weights = (accuracies ** P_POWER)
weights = weights / weights.sum()

print(f"\n  -> Power Blend (P={P_POWER}):")
for name, weight in zip(model_names, weights):
    print(f"    - {name}: {weight:.4f}")

# Blend pondéré
blend_oof = sum(w * oof_predictions[name] for w, name in zip(weights, model_names))
blend_test = sum(w * test_predictions[name] for w, name in zip(weights, model_names))

# Meta-stacking avec Logistic Regression
meta_features_train = np.hstack([oof_predictions[name] for name in model_names])
meta_features_test = np.hstack([test_predictions[name] for name in model_names])

# Normalisation
scaler = StandardScaler()
meta_features_train = scaler.fit_transform(meta_features_train)
meta_features_test = scaler.transform(meta_features_test)

# Méta-modèle
meta_model = LogisticRegression(
    max_iter=1500,
    multi_class='multinomial',
    solver='lbfgs',
    C=2.5,
    class_weight='balanced',
    n_jobs=-1,
    random_state=SEED
)
meta_model.fit(meta_features_train, y_train)

stack_oof = meta_model.predict_proba(meta_features_train).astype(np.float32)
stack_test = meta_model.predict_proba(meta_features_test).astype(np.float32)

stack_accuracy = accuracy_score(y_train, stack_oof.argmax(1))
print(f"\n  -> Meta-Model Accuracy: {stack_accuracy:.5f}")

# Calibration par température
def softmax_with_temperature(logits, T=1.0):
    """Applique softmax avec calibration de température."""
    logits = logits / max(T, 1e-6)
    logits = logits - logits.max(axis=1, keepdims=True)
    exp_logits = np.exp(logits)
    return (exp_logits / exp_logits.sum(axis=1, keepdims=True)).astype(np.float32)

def proba_to_logit(proba, eps=1e-9):
    """Convertit probabilités en logits."""
    proba = np.clip(proba, eps, 1 - eps)
    return np.log(proba)

def find_best_temperature(oof_proba, y_true, temps=[0.8, 0.9, 1.0, 1.1]):
    """Trouve la meilleure température pour calibration."""
    logits = proba_to_logit(oof_proba)
    best_T, best_acc = 1.0, -1

    for T in temps:
        calibrated = softmax_with_temperature(logits, T)
        acc = accuracy_score(y_true, calibrated.argmax(1))
        if acc > best_acc:
            best_acc, best_T = acc, T

    return best_T

# Trouver les meilleures températures
T_blend = find_best_temperature(blend_oof, y_train)
T_stack = find_best_temperature(stack_oof, y_train)

print(f"  -> Température optimale Blend: {T_blend}")
print(f"  -> Température optimale Stack: {T_stack}")

# Appliquer les températures
blend_test_calibrated = softmax_with_temperature(proba_to_logit(blend_test), T_blend)
stack_test_calibrated = softmax_with_temperature(proba_to_logit(stack_test), T_stack)

# Lissage ordinal (pour variables ordinales)
def ordinal_smoothing(proba, alpha=0.10):
    """
    Lisse les probabilités entre classes adjacentes.
    Utile car la qualité de la bière est ordinale (3 < 4 < 5...).
    """
    N, K = proba.shape
    smoothed = proba.copy()

    for k in range(K):
        left = proba[:, k-1] if k > 0 else 0.0
        right = proba[:, k+1] if k+1 < K else 0.0
        smoothed[:, k] = (1 - 2*alpha) * proba[:, k] + alpha * left + alpha * right

    # Renormaliser
    smoothed = smoothed / smoothed.sum(axis=1, keepdims=True)
    return smoothed.astype(np.float32)

blend_test_calibrated = ordinal_smoothing(blend_test_calibrated, alpha=0.12)
stack_test_calibrated = ordinal_smoothing(stack_test_calibrated, alpha=0.12)

# Fusion finale (92% stack, 8% blend)
META_WEIGHT = 0.92
final_predictions = (META_WEIGHT * stack_test_calibrated +
                    (1 - META_WEIGHT) * blend_test_calibrated)

print(f"  -> Fusion finale: {META_WEIGHT*100:.0f}% Stack + {(1-META_WEIGHT)*100:.0f}% Blend")

# ============================
# GÉNÉRATION DE LA SOUMISSION
# ============================
print("\n[8/8] Génération du fichier de soumission...")

# Prédictions finales
final_class_predictions = final_predictions.argmax(1)
final_quality_predictions = le_target.inverse_transform(final_class_predictions)

# Créer le fichier de soumission
submission = sample_submission.copy()
submission[target] = final_quality_predictions

# Sauvegarder
submission_path = SCRIPT_DIR / "submission.csv"
submission.to_csv(submission_path, index=False)

print(f"  OK Fichier de soumission sauvegardé: {submission_path}")

# Vérification du format
print(f"\n  -> Vérification du fichier:")
print(f"    - Colonnes: {list(submission.columns)}")
print(f"    - Nombre de lignes: {len(submission)}")
print(f"    - Distribution des prédictions:")
for quality, count in submission[target].value_counts().sort_index().items():
    print(f"      Qualité {quality}: {count} ({count/len(submission)*100:.1f}%)")

# ============================
# RAPPORT FINAL
# ============================
elapsed_time = time.time() - start_time
minutes, seconds = divmod(int(elapsed_time), 60)

print("\n" + "="*70)
print("RAPPORT FINAL")
print("="*70)
print(f"\nTemps d'exécution: {minutes} min {seconds} sec")
print(f"\nPerformances des modèles (OOF Accuracy):")
for name, score in sorted(model_scores.items(), key=lambda x: x[1], reverse=True):
    print(f"  - {name:4s}: {score:.5f}")
print(f"\nEnsemble:")
print(f"  - Blend:       {accuracy_score(y_train, blend_oof.argmax(1)):.5f}")
print(f"  - Meta-Stack:  {stack_accuracy:.5f}")

print(f"\nFichiers générés:")
print(f"  - submission.csv")
print(f"  - {len(list(viz_dir.glob('*.png')))} visualisations dans {viz_dir}/")
print(f"  - {len(list(viz_dir.glob('*.csv')))} fichiers CSV d'analyse")

print("\n" + "="*70)
print("SOUMISSION PRETE POUR KAGGLE!")
print("="*70)
print(f"\nFichier à soumettre: submission.csv")
print("Score attendu: > 0.48 (objectif: 0.48-0.49+)")
print("\nBonne chance! ")
